﻿namespace nspector.Common
{
    public enum SettingViewMode
    {
        Normal,
        IncludeScannedSetttings,
        CustomSettingsOnly,
    }
}
