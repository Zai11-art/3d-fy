﻿namespace nspector.Common.Meta
{
    internal class MetaServiceItem
    {
        public ISettingMetaService Service { get; set; }
        public uint ValueNamePrio { get; set; }
    }
}