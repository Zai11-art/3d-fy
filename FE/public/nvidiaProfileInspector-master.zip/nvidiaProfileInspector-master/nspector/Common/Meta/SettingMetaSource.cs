﻿namespace nspector.Common.Meta
{
    public enum SettingMetaSource
    {
        CustomSettings = 10,
        DriverSettings = 20,
        ConstantSettings = 30,
        ReferenceSettings = 40,
        ScannedSettings = 50,
    }
}
