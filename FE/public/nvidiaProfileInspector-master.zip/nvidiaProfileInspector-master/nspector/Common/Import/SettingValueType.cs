﻿namespace nspector.Common.Import
{
    public enum SettingValueType : int
    {
        Dword,
        AnsiString,
        String,
        Binary
    }
}