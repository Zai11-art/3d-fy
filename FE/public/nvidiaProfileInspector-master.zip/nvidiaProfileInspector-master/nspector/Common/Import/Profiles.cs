using System;
using System.Collections.Generic;

namespace nspector.Common.Import
{
    [Serializable]
    public class Profiles : List<Profile>
    {

    }
}